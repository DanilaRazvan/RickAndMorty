package com.bearddr.rickandmorty.ui.details

sealed class UiEvents {
  object GetEpisodesEvent: UiEvents()
}
