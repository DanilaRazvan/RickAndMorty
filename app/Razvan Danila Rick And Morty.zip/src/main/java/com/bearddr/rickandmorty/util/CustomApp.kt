package com.bearddr.rickandmorty.util

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class CustomApp: Application()